function hello() {
  console.log ("Hello world");
};