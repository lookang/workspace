var game_title = "Demo Game";

var max_question_per_game = 5;

var raw_data=[
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Paste the excel data here.
// Start pasting:


"	1 I am (gone) to eat you.	|	going	|	went	|	goes	|	go	"
, "	2 Janice (run) like a mad man when she meets a zombie.	|	runs	|	run	|	ran	|	running	"
, "	3 Zombie Su Lin (enjoy) slurping fresh brain with a straw.	|	enjoys	|	enjoy	|	enjoyed	|	enjoyable	"
, "	5 There (be) five survivors from the zombie apocalypse.	|	are	|	is	|	was	|	were	"
, "	6 I (be) going to eat you.	|	am	|	is	|	are	|	was	"
, "	7 After (taste) the human, Zombie spat it out.	|	tasting	|	tasted	|	tastes	|	taster	"
, "	8 The survivors (hide) in the secret underground tunnel.	|	hide	|	hid	|	hidden	|	hiding	"
, "	9 When you block the zombies out, you are (be) a good defender.	|	being	|	been	|	was	|	is	"
, "	10 I will be (watch) the movie.	|	watching	|	watched	|	watches	|	watcher	"
, "	11 I have been (practised) for the exam.	|	practising	|	practises	|	practise	|	practition	"
, "	12 They were (buy) souvenirs for their friends.	|	buying	|	bought	|	brought	|	buys	"
, "	13 He is (see) the doctor now.	|	seeing	|	seen	|	saw	|	sees	"
, "	14 Who are you (look) for?	|	looking	|	looks	|	look	|	looker	"
, "	15 Janice (run) like a mad man when she meets a zombie.	|	runs	|	run	|	ran	|	running	"
, "	16 Zombie Su Lin (enjoy) slurping fresh brain with a straw.	|	enjoys	|	enjoy	|	enjoyed	|	enjoyable	"
, "	18 There (be) five survivors from the zombie apocalypse.	|	are	|	is	|	was	|	were	"
, "	19 I (be) going to eat you.	|	am	|	is	|	are	|	was	"
, "	20 After (taste) the human, Zombie spat it out.	|	tasting	|	tasted	|	tastes	|	taster	"
, "	21 The survivors (hide) in the secret underground tunnel.	|	hide	|	hid	|	hidden	|	hiding	"
, "	22 When you block the zombies out, you are (be) a good defender.	|	being	|	been	|	was	|	is	"
, "	23 I will be (watch) the movie.	|	watching	|	watched	|	watches	|	watcher	"
, "	24 I have been (practised) for the exam.	|	practising	|	practises	|	practise	|	practition	"
, "	25 They were (buy) souvenirs for their friends.	|	buying	|	bought	|	brought	|	buys	"
, "	26 He is (see) the doctor now.	|	seeing	|	seen	|	saw	|	sees	"
, "	27 Who are you (look) for?	|	looking	|	looks	|	look	|	looker	"
, "	28 Janice (run) like a mad man when she meets a zombie.	|	runs	|	run	|	ran	|	running	"
, "	31 There (be) five survivors from the zombie apocalypse.	|	are	|	is	|	was	|	were	"
, "	32 I (be) going to eat you.	|	am	|	is	|	are	|	was	"
, "	33 After (taste) the human, Zombie spat it out.	|	tasting	|	tasted	|	tastes	|	taster	"
, "	34 The survivors (hide) in the secret underground tunnel.	|	hide	|	hid	|	hidden	|	hiding	"
, "	35 When you block the zombies out, you are (be) a good defender.	|	being	|	been	|	was	|	is	"
, "	36 I will be (watch) the movie.	|	watching	|	watched	|	watches	|	watcher	"
, "	37 I have been (practised) for the exam.	|	practising	|	practises	|	practise	|	practition	"
, "	38 They were (buy) souvenirs for their friends.	|	buying	|	bought	|	brought	|	buys	"
, "	39 He is (see) the doctor now.	|	seeing	|	seen	|	saw	|	sees	"
, "	40 Who are you (look) for?	|	looking	|	looks	|	look	|	looker	"
, "	41 Janice (run) like a mad man when she meets a zombie.	|	runs	|	run	|	ran	|	running	"
, "	42 Zombie Su Lin (enjoy) slurping fresh brain with a straw.	|	enjoys	|	enjoy	|	enjoyed	|	enjoyable	"
, "	44 There (be) five survivors from the zombie apocalypse.	|	are	|	is	|	was	|	were	"
, "	45 I (be) going to eat you.	|	am	|	is	|	are	|	was	"
, "	46 After (taste) the human, Zombie spat it out.	|	tasting	|	tasted	|	tastes	|	taster	"
, "	47 The survivors (hide) in the secret underground tunnel.	|	hide	|	hid	|	hidden	|	hiding	"
, "	48 When you block the zombies out, you are (be) a good defender.	|	being	|	been	|	was	|	is	"
, "	49 I will be (watch) the movie.	|	watching	|	watched	|	watches	|	watcher	"
, "	50 I have been (practised) for the exam.	|	practising	|	practises	|	practise	|	practition	"


// End of pasting.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
];