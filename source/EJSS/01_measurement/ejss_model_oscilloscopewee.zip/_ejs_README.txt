<This document was created with EjsS version 5.3 (build 180211)>

All the files and subdirectories in this directory were extracted from a compressed ZIP file, and contain a Javascript simulation and its auxiliary files, created with Easy Java(script) Simulations <http://www.um.es/fem/EjsWiki>.

A simulation directory has several HTML or XHTML files in it:
  - A main XHTML file named as the simulation.
  - A table of contents XHTML file, named as the simulation plus a “_Contents” suffix.
  - A simulation XHTML file, named as the simulation plus a “_Simulation” suffix.
  - Possibly, other HTML or XHTML description pages, as included by the author.

To access the complete model with its description pages and simulation in a frame, open the main XHTML file with your favorite browser.

To just run the simulation, open the XHTML file that ends with the "_Simulation" prefix.

A simulation directory also contains a _metadata.txt file that you can inspect to get machine-generated information about the simulation and the different files contained in it.

The simulation ZIP file can also be run on tablets using the EjsS Reader App available in Apple iTunes and in the Google Play store.